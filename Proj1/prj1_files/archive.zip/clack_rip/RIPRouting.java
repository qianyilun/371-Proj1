
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;

import net.clackrouter.component.base.ClackComponent;
import net.clackrouter.component.base.ClackPort;
import net.clackrouter.component.base.Interface;
import net.clackrouter.component.simplerouter.IPRouteLookup;
import net.clackrouter.netutils.NetUtils;
import net.clackrouter.packets.RIPRoutingUpdate;
import net.clackrouter.packets.VNSIPPacket;
import net.clackrouter.packets.VNSPacket;
import net.clackrouter.router.core.LocalLinkChangedListener;
import net.clackrouter.router.core.Router;
import net.clackrouter.routing.LocalLinkInfo;
import net.clackrouter.routing.RIPRoutingEntry;
import net.clackrouter.routing.RoutingTable;

public class RIPRouting extends ClackComponent implements LocalLinkChangedListener {
	
	// do not modify these port values
	public static final int PORT_UPDATE_IN = 0, PORT_UPDATE_OUT = 1, NUM_PORTS = 2;
	
	public static int PERIODIC_UPDATE_MSEC = 10000; // 10 seconds	
	public static int TIMER_INTERVAL_MSEC = 1000; // 1 second	
	public static int INFINITE_COST = 200;
	public static short MAX_TTL = 20;
	
	
	public RoutingTable mRtable;
	
public RIPRouting(Router r, String name){
	super(r, name);	
	setupPorts(NUM_PORTS);
		
	mRtable = mRouter.getRoutingTable();

	add_local_routes();
		
	// get updates from the router when our status changes. 
	mRouter.addLocalLinkChangeListener(this);
		
	// this will start timer after 5 seconds
	setTimer(5 * TIMER_INTERVAL_MSEC);
}


// sets up component ports (do not modify)  	
protected void setupPorts(int numports){
    	super.setupPorts(numports);
        String in_desc = "Routing updates address to local interfaces";
        String out_desc     = "Outgoing routing updates";
        m_ports[PORT_UPDATE_IN] = new ClackPort(this, PORT_UPDATE_IN, in_desc, 
			ClackPort.METHOD_PUSH, ClackPort.DIR_IN, VNSIPPacket.class);
        m_ports[PORT_UPDATE_OUT]     = new ClackPort(this, PORT_UPDATE_OUT, out_desc, 
			ClackPort.METHOD_PUSH, ClackPort.DIR_OUT, VNSIPPacket.class);
} // -- setupPorts
	

// adds local routes to the routing table of this router.  
// This includes a /32 for each interface on the router, and a /31 
// for any subnet that it has an interface connected to
// Also adds a default route if the router is configured with one
private void add_local_routes(){
	try {
		Hashtable local_links = getRouter().getLocalLinkInfo();
		InetAddress full_mask = InetAddress.getByName("255.255.255.255");
			
		// examine each local link and see what routes to add
		for(Enumeration e = local_links.keys(); e.hasMoreElements(); ){
		
			String iface_str = (String) e.nextElement();
			LocalLinkInfo info = (LocalLinkInfo) local_links.get(iface_str);
				
			// Add a route for each of our local interfaces
			Interface iface = mRouter.getInterfaceByName(iface_str);
			RIPRoutingEntry local_iface_entry = new RIPRoutingEntry(iface.getIPAddress()
					, full_mask, null, null, MAX_TTL, 0, true);
			mRtable.addEntry(local_iface_entry);
			
			// only add route for a connected subnet (/31) if it is more than the 
			// /32 we advertised already
			if(!info.subnet_mask.equals(full_mask)) {
				RIPRoutingEntry new_entry = new RIPRoutingEntry(info.network, 
						info.subnet_mask, info.next_hop, iface_str, 
						MAX_TTL, Router.DEFAULT_ROUTE_METRIC, true);
				mRtable.addEntry(new_entry);
			}

		}
			
		// if we have a default route, install it.  
		if(mRouter.getDefaultNextHop() != null){
			InetAddress all_zeros = InetAddress.getByName("0.0.0.0");
			RIPRoutingEntry default_entry = new RIPRoutingEntry(all_zeros, all_zeros, 
				mRouter.getDefaultNextHop(), mRouter.getDefaultRouteIface(), 
				MAX_TTL, Router.DEFAULT_ROUTE_METRIC, true);
			mRtable.addEntry(default_entry);
		}
			
	} catch (Exception ex){
		System.err.println("Error while installing local routes at " 
				+ mRouter.getHost());
			ex.printStackTrace();
	}			
}
	
	
// called whenever the router receives a RIP packet	
public void acceptPacket(VNSPacket packet, int port_number) {
    	if(port_number != PORT_UPDATE_IN) return;
    	
    	VNSIPPacket ip_packet = (VNSIPPacket)packet;
        byte protocol = ip_packet.getHeader().getProtocol();
            
        if(protocol != VNSIPPacket.PROTO_CLACK_RIP) return;
        
	System.out.println("Received Routing Packet!  Dropping ...");
	signalError(); // flash red to signal an error
    
	// your code goes here 
	            	
}
    
    
// Callback for the provided timer facility.  Helpful for implementing
// periodic functionality  and decrementing TTLs
public void timerCallback(){

	System.out.println("Hello from the timer call-back!");
    	
	// update the GUI view of the routing table (keep this)
    	mRouter.updateRouteTableStateInGUI();
    			
	// reschedule timer
    	setTimer(TIMER_INTERVAL_MSEC); 
}

// A call-back function used by the Router to inform the RIP module if 
// any characteristics of the local links have been changed.  
public void localLinkChanged(LocalLinkInfo old_info, LocalLinkInfo new_info){

    if(old_info.is_up != new_info.is_up){
    	System.out.println("Link Status Changed");
    }else if(old_info.metric != new_info.metric){
    	System.out.println("Link Metric Changed");
    }

}

// send a RIPRoutingUpdate packet to dst
protected void sendUpdate(InetAddress src, InetAddress dst, 
		RIPRoutingUpdate update){

	try {
		VNSIPPacket ip_packet = VNSIPPacket.wrap(update, 
				VNSIPPacket.PROTO_CLACK_RIP, src, dst);
		m_ports[PORT_UPDATE_OUT].pushOut(ip_packet);
	} catch (Exception ex){
		System.err.println("Error sending routing update packet from " 
				+ src.getHostAddress() + " to " + dst.getHostAddress());
		ex.printStackTrace();
	}	

}
// utility function for printing the contents of a RIP routing table
// You do not need to modify this function, but feel free to make changes for debugging.      
public void dumpRIPRoutingTable(){

    	System.out.println("Routing table for " + mRouter.getHost() + " : (" + 
				mRtable.numEntries() + " entries)");
    	for(int i = 0; i < mRtable.numEntries(); i++){
    		RIPRoutingEntry rip_entry = (RIPRoutingEntry)mRtable.getEntry(i);
    		String prefix = NetUtils.NetworkAndMaskToString(rip_entry.destination, 
						rip_entry.mask);
    		if(rip_entry.nextHop != null){
    			System.out.println(prefix + " : " + rip_entry.nextHop.getHostAddress() + 
				" via " + rip_entry.interface_name
    				+ " cost = " + rip_entry.cost + " ttl = " + rip_entry.ttl);
    		}else {
    			System.out.println(prefix + " : * via * "
        				+ " cost = " + rip_entry.cost + " ttl = " + rip_entry.ttl);
    		}
    	}  
}

}
